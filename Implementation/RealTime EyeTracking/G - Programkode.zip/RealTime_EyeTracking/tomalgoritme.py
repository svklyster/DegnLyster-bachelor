import numpy as np
import EyeTracking as et

#Her tilf�jes diverse python-biblioteker

def Track(frame, calibration_data, variables):

    #Egen kode her 
    
    et.PackWithTimestamp(screen_point, trigger_value)
    et.LastRunInfo(variables)
    return